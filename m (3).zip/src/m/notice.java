package m;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.CardLayout;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URL;

import javax.swing.ListSelectionModel;

public class notice {

	private JFrame frame;

	   /**
	    * Launch the application.
	    */
	   public static void main(String[] args) {
	      EventQueue.invokeLater(new Runnable() {
	         public void run() {
	            try {
	               notice window = new notice();
	               window.frame.setVisible(true);
	            } catch (Exception e) {
	               e.printStackTrace();
	            }
	         }
	      });
	   }

	   /**
	    * Create the application.
	    */
	   public notice() {
	      initialize();
	   }

	   /**
	    * Initialize the contents of the frame.
	    */
	   private void initialize() {
	      frame = new JFrame();
	      frame.getContentPane().setBackground(Color.WHITE);
	      frame.getContentPane().setLayout(null);
	      frame.setBounds(100, 100, 988, 638);
	      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	      
	      
	      
	      
	      JPanel panel = new JPanel();
	      panel.setBackground(Color.WHITE);
	      panel.setBounds(0, 0, 978, 600);
	      frame.getContentPane().add(panel);
	      
	      JComboBox comboBox = new JComboBox();
	      comboBox.setModel(new DefaultComboBoxModel(new String[] {"Q \uC790\uC8FC \uBB3B\uB294 \uC9C8\uBB38", "Q \uB530\uB989\uC774\uB97C \uC774\uC6A9\uD558\uACE0 \uC2F6\uC740\uB370 \uC5B4\uB5BB\uAC8C \uD574\uC57C \uD558\uB098\uC694?(\uAD6C\uB9E4/\uB300\uC5EC/\uBC18\uB0A9)", "Q \uC815\uAE30\uAD8C \uBC0F \uC774\uC6A9\uAD8C \uC774\uC6A9\uBC29\uBC95", "Q \uB530\uB989\uC774 \uBC18\uB0A9\uC740 \uC5B4\uB5BB\uAC8C \uD558\uB098\uC694?", "Q. \uB530\uB989\uC774 \uC2DC\uC124\uBB3C \uD604\uD669\uC744 \uC54C\uACE0 \uC2F6\uC2B5\uB2C8\uB2E4."}));
	      comboBox.setBounds(176, 407, 655, 32);
	      panel.add(comboBox);
	      
	      //���̺� �����
	      String[] colNames = {"����","��¥"};  // �÷���
	      Object[][] data = {
	            {"[�ȳ�] ������ �̿���� ������Ģ �ȳ�   ","2020.06.23"},
	            {"���������� ������ �濪, �̷��� �մϴ�!   ","2020.06.22"},
	            {"������ ���� �������� �ȳ�   ","2020.06.21"},
	            {"[������ ����] ������������� ������ ���ø�   ","2020.06.20"},            
	            };
	      
	      JButton btn_home = new JButton("");
	      btn_home.addMouseListener(new MouseAdapter() {
	         
	         public void mouseClicked(MouseEvent e) {
	            
	            frame.dispose();
	            home.main(null);
	            
	         }
	      });
	      btn_home.setBorderPainted(false);
	       btn_home.setContentAreaFilled(false);
	       btn_home.setFocusPainted(true);
	       
	      btn_home.setBounds(12, 23, 69, 61);
	      panel.add(btn_home);
	      
	      URL url = this.getClass().getResource("../image/notice.jpg");
	      String path = url.getPath(); /// url.getPaht << �� ��η� ����ϴ°� ����� 
	      Image image = new ImageIcon(path).getImage(); 
	      panel.setLayout(null);
	      
	      
	      JLabel lbl_notice = new JLabel(new ImageIcon(image.getScaledInstance(978, 600, Image.SCALE_SMOOTH)));
	      lbl_notice.setBounds(0, 0, 978, 610);
	      panel.add(lbl_notice);
	      

	      

	      

	      


	      
	      
	      
	   }
}
